package pl.umcs.oop.imageweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImagewebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImagewebApplication.class, args);
	}

}
