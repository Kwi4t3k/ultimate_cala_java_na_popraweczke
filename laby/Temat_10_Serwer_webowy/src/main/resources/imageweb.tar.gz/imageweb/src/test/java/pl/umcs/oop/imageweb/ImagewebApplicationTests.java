package pl.umcs.oop.imageweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImagewebApplicationTests {

	@Test
	void contextLoads() {
	}

}
